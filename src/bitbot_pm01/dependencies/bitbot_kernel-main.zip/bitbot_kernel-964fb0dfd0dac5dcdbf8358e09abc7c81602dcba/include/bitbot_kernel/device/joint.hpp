#pragma once

namespace bitbot
{
  enum class JointPowerOnState
  {
    Null = 0,
    Running,
    Finish,
    Error
  };
}